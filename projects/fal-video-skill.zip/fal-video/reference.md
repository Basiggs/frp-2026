# fal.ai → animated paper-collage videos (2026-09-25)

> **2026-10 update:** these are the first videos (Sep 2026). Current defaults are in `SKILL.md`: voice at 1x (no `atempo`), voice `Charlotte`, images from Codex first, template = the Zhanat ducks project. The fal image tricks below still apply to `fal_image.py`.

Three short explainer videos, each made end to end from one prompt. All media generation ran on **fal.ai**; the animation and rendering ran locally on foggen (4 vCPU, no GPU).

| # | Video | Length | fal cost | Output |
|---|-------|--------|----------|--------|
| 1 | "How to Find a Girlfriend in Astana (cat edition)" | 77 s | ≈ $2.89 | `~/cat-waifu-astana/cat_girlfriend_astana.mp4` (+ `_tg.mp4`, 43 MB) |
| 2 | "ISSAI Sunday Picnic" preview (letter-food rule) | 64 s | ≈ $1.65 | `~/issai-picnic/issai_picnic_preview.mp4` + `issai_picnic_poster.jpg` |
| 3 | "ISSAI Picnic: A Nature Documentary" (from the planning sheet, no names) | 88 s | ≈ $2.72 | `~/issai-picnic2/issai_picnic_documentary.mp4` |

**Total fal spend ≈ $7.26 of the $10 budget.** Claude's own tokens are not included. All three videos were sent to Kitan's Telegram (chat 1607870670) by the Yuuki bot. The bot used the Telegram Bot API `sendVideo`/`sendPhoto` directly, because the local `/reply` API only sends text. Video 1 also has a private viewing page: https://claude.ai/artifact/HJM98qHehBGh2rZq3YBcJH

Wall-clock time for video 1 was about 20 minutes, from the first fal call to the encoded MP4. Videos 2 and 3 took about 20–25 minutes each; frame rendering was the slowest step.

---

## fal.ai models used

| Purpose | Endpoint | Settings | List price |
|---------|----------|----------|------------|
| Backgrounds, props | `fal-ai/nano-banana-2` | `resolution: 1K`, `16:9` or `1:1`, png | $0.08 / image |
| On-model characters | `fal-ai/nano-banana-2/edit` | same, plus `image_urls: [ref…]` | $0.08 / image |
| Cut-outs (background removal) | `fal-ai/birefnet/v2` | `model: "General Use (Heavy)"` | ~$0.001 / image |
| Narration | `fal-ai/elevenlabs/tts/eleven-v3` | `voice: "George"`, `timestamps: true`, `language_code: en` | $0.10 / 1k chars |
| Music | `fal-ai/elevenlabs/music` | `force_instrumental: true`, `music_length_ms` 60–80 s | $0.60 / min |
| Sound effects | `fal-ai/elevenlabs/sound-effects/v2` | `duration_seconds` 0.6–8 | $0.002 / s |

Prices come from `GET https://api.fal.ai/v1/models/pricing?endpoint_id=…`, which takes the same `Authorization: Key …` header as model calls. Images were kept at 1K, per the standing "low-res only" preference.

### Client

`fal.py` in each project folder is about 40 lines and calls the **queue API** with plain `requests` (the `fal_client` package isn't installed):

1. `POST https://queue.fal.run/{model}` with `Authorization: Key $FAL_KEY` returns `status_url` and `response_url`.
2. Poll `status_url` every 2 s until `COMPLETED`, then `GET response_url`.
3. Download the media URLs and append the call to `fal_log.jsonl` for cost tracking.

The key lives in `~/.config/fal/key` (mode 600) or `$FAL_KEY`; projects no longer keep their own copy. Up to 10 calls run in parallel on a `ThreadPoolExecutor`, so every image, voice clip, music track and SFX for one video finished in roughly 1–3 minutes.

### Tricks that mattered

- **Character consistency.** Generate a reference image first, then draw every later pose with `nano-banana-2/edit`, passing the reference URL in `image_urls`. For group shots, pass all the character references at once; 7 refs worked fine.
- **Cut-outs for real collage motion.** Characters and props were generated alone on a plain white background, then run through BiRefNet. Each became a separate transparent layer that moves on its own. A white "paper sticker" outline was added in PIL rather than CSS, which keeps rendering cheap.
- **One shared style prefix** ("hand-made paper collage, torn edges, gouache and colored-pencil texture…") at the start of every prompt kept all the images visually consistent.
- **Word timestamps from ElevenLabs v3** drive everything: karaoke captions, gags keyed to specific spoken words (the phone falls on "Knocking", the chicken clucks on "chicken"), and SFX placement in the mix.
- **Music fitted to the edit.** `silencedetect` finds the track's natural ending, then `atempo` stretches it so the ending lands on the final card. In video 3 the music starts after a birdsong intro, to avoid slowing the dombra too much.
- **Retakes were cheap.** Two off-model images were redrawn for $0.08 each: blue cat ears in video 1, and a mandolin-shaped dombra in video 3. The dombra fix needed an explicit description: long thin neck, pear-shaped body, two strings.

---

## Pipeline (same for all three)

1. **Script and shot list** in `script.json`: scenes, narration lines, and background, character and prop prompts.
2. **`gen.py`** runs all fal jobs in parallel. Characters are generated first, then the group shot is made from their URLs.
3. **Review** of contact sheets of the backgrounds and cut-outs, with redraws where needed.
4. **`prep.py`:**
   - trims cut-outs and converts them to webp
   - speeds up the voice-over with `atempo` (1.12–1.15×)
   - turns character timestamps into word timings and writes `web/timeline.js`
   - mixes the audio with ffmpeg: voice, music ducked under the voice, SFX on cue words, loudness at −15 LUFS
5. **`web/index.html`:** a seekable HTML/JS collage engine with `window.seek(t)`. It has Ken Burns backgrounds, torn-paper page transitions, "boiling" stop-motion jitter at 8 fps, ransom-note chip labels, karaoke captions, and canvas particles (snow, leaves).
6. **`render.cjs`:** headless Chromium via Playwright. Three pages seek and screenshot each frame (1920×1080, 30 fps, about 1.5–2.5 fps overall).
7. **ffmpeg** encodes H.264 + AAC with faststart. Telegram copies are kept under 50 MB, the Bot API upload limit.

Re-render any project with:
```bash
cd ~/<project> && node render.cjs frames 30 3 && \
ffmpeg -framerate 30 -i render/frames/f%05d.jpg -i web/mix.m4a -c:v libx264 -b:v 4300k -pix_fmt yuv420p -c:a aac -shortest -movflags +faststart out.mp4
```
For preview stills only: `node render.cjs stills 1.5 12 40`.

---

## Per-video notes

**1. Cat-girlfriend in Astana.** Eight scenes at Astana landmarks: Baiterek, Khan Shatyr, a dastarkhan with baursaks, a cat café, the Esil at sunset, a buran, and an apartment ending. It used 25 images, 8 TTS clips, 1 music track and 6 SFX. This replicated the Reddit "Opus one-prompt video" experiment ($3.21 on OpenRouter, about 1 h 20 min there) on fal only.

**2. ISSAI picnic preview.** Teammates are shown as steppe animals so nobody's appearance has to be guessed: a snow leopard, hedgehog, marmot, corsac fox and owl. The rule is to bring food starting with your first letter: Aport apples, ayran, achichuk (with an "A is overbooked" stamp), grapes, and vareniki with a huge thermos. A letter menu covers everyone else, and a poster still was also sent. 12 images.

**3. Nature documentary.** Built from the real `ISSAI_gathering` sheet, with names redacted. It covers:
- the "something starting with A" entries and the Cyrillic loophole (АРАХИС / АЙРАН / АБРИКОС)
- the chicken / pigeon / pheasant hunt
- the "not vegetarian / why?????" debate
- the 20 L canister, "liters TBD"
- the games list
- "can you play dombra? — I can play dorama"

It has 7 new Botanical Garden backgrounds and a dombra-led soundtrack. 22 images. The Cyrillic tiles needed the Rubik Mono One Cyrillic font subset.

**4. FRP 2026 AI Engineering promo (2026-10-09, `~/frp-video`).** 97 s, paper collage, 11 scenes: NU campus intro,
an 8-station road map, one scene per day with an 8-day strip on top, Demo Day, an end card. 17 Codex images (NU-inspired
campus, Senate Hall, ISSAI supercomputer room, ISSAI office with the Astana skyline, demo stage; stylized teens).
Charlotte voice, fresh ElevenLabs music (uplifting piano + strings + dombra motif). fal $1.43 in total, including
3 versions of the narration: "Fall" was heard as "Full" by Whisper in the last line 3 times, so the line was
rephrased; then Kitan chose ISSAI = "Issai" and Astana = "Astaná" from test clips (now in `template/say.py`).
Test clips: `~/frp-video/assets/audio/{issai_test,astana_test}/`. Render 2975 frames: 456 s with 3 workers.

**5. FRP 2026 AI Engineering + Robotics promo (2026-10-09, `~/frp-mix-video`).** 94 s, 3D clay style (only the
style prefix changed), 11 scenes: "8 days, 2 paths" map with a teal AI road and a coral Robotics road that meet at
the Demo Day stage (the AI mascot drives one road, the drone flies along the other, using measured road points), a
two-lane strip on top of every scene, a drone flying a figure eight, a soft continuum robot and a robotic arm.
17 Codex images, new ElevenLabs music (synth + brass + dombra riff). fal $1.18. Render 2830 frames: about 7 min
with 2 workers in the foreground, RAM stayed about 7 GB free. Kitan: "good one, keep logic how you did it".

## Music models on fal (2026-10-09, list prices; only ElevenLabs is tested)

Cost for a 100 s instrumental track. Check each model's commercial-use license before an official promotion.

| Model | Price | ~100 s | Max length |
|---|---|---|---|
| `fal-ai/elevenlabs/music` (also `elevenlabs/music/v2`, `v2.5`) | $0.60 / min | $1.00 | free |
| `minimax/music-3` | $0.002 / s | $0.20 | 300 s |
| `fal-ai/minimax-music/v2.6` | $0.15 / track | $0.15 | ? (song-oriented, `is_instrumental`) |
| `fal-ai/stable-audio-3/medium/text-to-audio` | $0.0376 / track | $0.04 | 380 s |
| `fal-ai/ace-step/prompt-to-audio` | $0.0002 / s | $0.02 | 240 s (`instrumental`) |
| `cassetteai/music-generator` | $0.02 / min | $0.03 | 180 s |
| `fal-ai/lyria3`, `/pro`, `google/lyria-3.5` | $0.04 / $0.08 / $0.10 per track | ? | unknown clip length |

A same-prompt test on 5 of these costs about $0.40; listen before switching the default.

## Caveats

- Audio was checked only by silence detection and timestamps; nobody listened to it during the work. TTS pronunciation of Kazakh and Russian words (achichuk, qymyz, arakhis) is unverified.
- Rendering is CPU-bound on this VPS. An 80 s video takes about 15–20 minutes of frame capture.
- The intermediate frame dumps (about 1.2 GB per video) were deleted. The final MP4s, all generated assets and the scripts are kept in each project folder.
