---
name: fal-video
description: Make a short narrated animated video (paper-collage explainer, event teaser, meme, greeting, mock documentary) end to end from a prompt. Images from Codex (free, codex-image-gen), voice/SFX/music from ElevenLabs on fal.ai, cut-outs with BiRefNet on fal, then an HTML/JS collage engine rendered to MP4 on this CPU-only VPS and sent to Telegram. Use when Kitan asks for a video, animated explainer, teaser, "one-prompt video", or a fal.ai cost estimate.
---

# Narrated paper-collage video

fal cost, with Codex images (free):
- 15–20 s video: about $0.10 (voice + a few SFX, reused music). About 15 min of work.
- 60–90 s video: about $0.20 with a reused music track. New music adds $0.60 per minute of track,
  so about $1.00–1.40 with a fresh 90–120 s track (Battle Orin: $1.35, of which $1.20 was music). About 30–40 min.
Codex images are free but slow (2–4 min each, run them in parallel).
`reference.md` has older notes, prices and tricks (fal image generation, character refs).

## Kitan's rules

- **Voice at 1x always.** Never speed it up (`prep.py` has no tempo for the voice).
- **Female voice: ElevenLabs `Charlotte`** (Kitan disliked Sarah). Male lines: `Callum` or `George`.
- **Images: Codex first** (`codex-image-gen`, free). fal Nano Banana only as a fallback, `1K` only. Never OpenRouter.
- **No copyrighted music** (film themes etc.). Reuse an old track or generate one with ElevenLabs Music.
- Tell Kitan the estimated cost before spending. Report the real cost (`python fal.py cost`) at the end.
- Say plainly that you did not listen to the audio.
- Group videos about real people: draw animals/objects, not the person; keep the joke kind.
- The fal key: `fal.py` reads `$FAL_KEY` or `~/.config/fal/key`. Never print it or copy it into the project.
- **Pronunciation (Kitan chose by ear):** **ISSAI** is spoken as one word "Issai" (not the letters I-S-S-A-I),
  **Astana** with the stress at the end, "Astaná". `template/say.py` does it: write the official spelling in
  `script.json`, `gen_audio.py` sends the spoken form to the TTS, `prep.py` puts the official spelling back into the
  captions (so `wt("s1", "ISSAI")` still works). For a new hard word, make 5-7 test clips with different spellings
  (one sentence each, plus one file with a ding between them), let Kitan pick one, then add it to `SAY`.
  Check retakes with `fal-ai/whisper`; Whisper often writes "Issai" as ISSAI / ISAI / eSci, which is fine.
- **Low RAM on foggen:** check `free -m` first (need about 1.5 GB available), render with 2 workers in the foreground,
  ffmpeg with `-threads 2`. If a render is stopped, `RESUME=1 node render.cjs frames 30 2` keeps the finished frames.

## Steps

1. **Scaffold:** `bash ~/skills/fal-video/new.sh ~/<project>`, then `cd` into it.
   `template/` is a real finished 19 s video (Zhanat team-building ducks): replace its content.
2. **Script** (`script.json`): `voice` plus `scenes` (`id`, `text`, optional `voice`, `lang`).
   About 2.5 words per second. v3 audio tags like `[laughs]` work; `prep.py` drops them from the captions.
3. **Images** (`images.sh`): edit the requests and run it. Characters and props on plain white
   (they become cut-outs); backgrounds as `assets/img/bg_<name>.png`. Use one shared style prefix.
   Look at every image with Read; redraw any that is off. Old projects have reusable backgrounds:
   `~/issai-picnic*/assets/img/bg_*.png`, `~/cat-waifu-astana/assets/img/bg_*.png`.
4. **Cut-outs:** `python cutout.py ducks,dove` → `web/a/o_<name>.webp` (BiRefNet on fal, < $0.01 each).
5. **Audio:** set `SFX` (and `MUSIC` if no track is reused) in `gen_audio.py`, run `python gen_audio.py`.
   Retake one scene: `python gen_audio.py s3`. Reuse music: `cp ~/<old>/assets/audio/music.mp3 assets/audio/`.
6. **Timeline and mix** (`cfg.json`, then `python prep.py`): `lead`/`tail` = pauses per scene,
   `cues` = `[scene, word prefix or null, sfx, offset, gain]`, `music_tempo` stretches only the music.
   It writes `web/timeline.js` and `web/mix.m4a`, converts `bg_*.png` to webp, and prints every word time.
7. **Animation** (`web/index.html`): rewrite only the `BG` map (scene → background) and the
   `defScene(...)` blocks. Building blocks:
   - `new Cut(L, name, x, y, h)` + `.set(t, {dx, dy, s, r, op, flip})`: cut-out anchored bottom-center
   - `placeIn(t, at)`: drop-in pop
   - `new Chip(L, text, x, y, size, seed, {rot, font})` + `.set(t, at, {out})`: ransom-note label
   - `paperTag` / `showTag`: small paper note
   - `kenBurns(this.bg, t, s.dur, {...})`: background drift
   - `wt("s2", "ducks")`: local time of a spoken word, used to time every gag
   - `lerp`, `P`, `eOutBack`, `eInOut`, `boil`: motion helpers

   Emoji: use a separate element with class `emo` (Noto Color Emoji). `🕊` inside a Chip shows nothing.
   Cyrillic text: the `Rubik Mono One` face covers it.
8. **Preview:** `node render.cjs stills 1.5 6 12` → `render/stills/`. View them, fix overlaps, repeat.
9. **Render** (in the background for long videos):
   ```bash
   node render.cjs frames 30 3 && \
   ffmpeg -y -framerate 30 -i render/frames/f%05d.jpg -i web/mix.m4a -c:v libx264 -crf 20 \
     -pix_fmt yuv420p -c:a aac -b:a 192k -shortest -movflags +faststart <name>.mp4 && rm -r render/frames
   ```
10. **Deliver** with the `telegram-report` skill (≤ 50 MB plays inline; else re-encode with `-crf 26`):
    `node ~/skills/telegram-report/scripts/tg_send.mjs "short text" <name>.mp4`
11. Append a `WORK_LOG.md` entry with the path and the fal cost.

## Recipe: program / event promo (FRP 2026, Kitan liked it)

Two finished examples (copy their scene code from `examples/`):
- `~/frp-video` (97 s, paper collage): one track, 8-day strip on every day scene, road map with 8 stations.
  Code: `examples/frp_program_collage_scenes.js` (`dayStrip`, `dayChips`, `emoji`, `pop`, map stations, `endcard`).
- `~/frp-mix-video` (94 s, 3D clay): two tracks, two-lane strip (AI teal / Robotics coral), two roads that meet at
  Demo Day, movers along measured road points, a drone flying a figure eight.
  Code: `examples/frp_two_tracks_clay_scenes.js` (`lanes`, `badge(..., bg)`, `along(points, k)`, figure-eight).

What made them work:
1. **Story (11 scenes, ~170 words, ~95 s):** intro at the place (who, where) → overview map ("8 days, 2 paths")
   → one scene per day or per track → testing → Demo Day → outro with the one key message + end card
   (title, track, dates, place). Every scene shows where it sits in the program (strip or lanes at the top).
2. **One color per track** (chips with `bg`, lane dots, road colors) so viewers follow two tracks without words.
3. **Backgrounds:** ask for "empty foreground space, no people, no text". For a map, describe the roads exactly
   (start, end, colors). After the image exists, measure road points (image px × 1920 / image width) and move
   cut-outs along them with `along()`. Real Astana landmarks (Baiterek, Ak Orda) come out well.
4. **Style per video** changes only the shared prefix. Clay prefix that worked: "Cute 3D clay diorama illustration:
   plasticine and polymer clay textures, soft studio lighting, rounded friendly shapes, tilt-shift miniature look,
   bright cheerful colors (mint green, coral, sunny yellow, sky blue, lavender), no text, no letters, no logos".
   People: stylized teens only, no real faces.
5. **Review loop:** one PIL contact sheet of all cut-outs, then 12 stills (near the end of each scene) as two
   contact sheets. Typical fixes: two title chips on two rows, spread word chips apart, no topic chip that repeats a
   word chip. Re-render only the changed stills.
6. **Voice:** official spelling in `script.json` (`say.py` fixes ISSAI/Astana). Check names with Whisper. If one word
   keeps being misheard in one position after 2 retakes ("Fall" heard as "Full"), rephrase the line instead.
7. **Render** in the foreground with 2 workers (about 7 min for 95 s), ffmpeg `-threads 2`, then a `-crf 26` copy
   for Telegram (20-29 MB). fal cost: about $1.2 with new music, about $0.2 with a reused track.
   Reusable 100 s tracks: `~/frp-video/assets/audio/music.mp3` (uplifting piano, strings, dombra motif),
   `~/frp-mix-video/assets/audio/music.mp3` (energetic synth, brass, dombra riff).

## Recipe: workshop explainer, no music, all on fal (16 Oct 2026, `~/promo-workshop-video`)

"How we made the FRP promo" for a staff workshop: 179 s, 11 scenes, fal $0.44 (voice $0.26, 2 backgrounds $0.16).
- **No music:** `cfg.json` without a `music` key; SFX only on the words that name them (`["s6", "whoosh", "whoosh", ...]`).
- **All on fal (for people without Codex, Kitan 16 Oct):** backgrounds with `python fal_image.py assets/img/bg_x.png "<style>, ..." 16:9`
  (Nano Banana 2, 1K, $0.08 each); cut-outs BiRefNet; voice, SFX, Whisper: one fal key does the whole pipeline.
- **Real material beats new pictures:** frames of the earlier videos (`ffmpeg -ss T -i old.mp4 -frames:v 1`), a raw picture
  next to its cut-out, the real `script.json`, the real `python fal.py cost` table as a receipt.
- **Explainer blocks** (own CSS + `box()`/`pop()` for DOM panels on top of the template engine, in
  `~/promo-workshop-video/web/_scenes.js`): typed terminal message, code card, framed photo, browser window, word timeline
  with a moving play head, film strip, receipt, phone frame, 2x2 lesson cards.
- **Say a domain:** `SAY["fal.ai"] = "fal-dot-A-I"` (one token with hyphens, so the caption maps back to `fal.ai`).
- Layout rule: Rubik Mono chip width is about 1.2 x size x letters; two chips longer than ~10 letters need two rows.

## Recipe: course explainer for non-technical students (16 Oct 2026, `~/llm-explainer-video`)

"How an LLM works", 176 s, 12 scenes, no music, fal $0.24. Reused backgrounds, robot, brain and SFX from
`~/promo-workshop-video`; 3 new Codex props. `assemble.sh` builds `index.html` from the workshop page + `_llm.css` + `_scenes.js`.
- **Real data on screen:** token pieces and IDs from a real tokenizer (`uv run --with tiktoken`, `o200k_base`); made-up
  numbers get a visible "example / made up for this video" label.
- **Class names collide:** the template head CSS already has `.ring` (margin -100px) and `.card` (46 px padding). Give new
  blocks their own names (`.rcard`, `.map .ring { margin: 0 }`), or measure with `getBoundingClientRect` when a box is off.
- **Draw in stage pixels:** the background sits at `left: 40px` in each sheet; put scene content in a `left: 40px` layer.
- **fal balance empty** (403 "User is locked. Reason: Exhausted balance"): Codex props on white can be cut out locally with
  `python3 template/cutout_local.py name ...` (numpy + scipy, removes border white and big white holes).
- Render speed on foggen: about 400 frames/min with 2 workers (176 s video = 13 min + 2 min encode).

## 4K and vertical (Instagram Reels) versions of a finished video

Audio, `timeline.js` and cut-outs are reused, so only images can cost money. Done for `~/frp-mix-video` (fal $0.06).
- **4K 16:9:** `python3 upscale.py` (SeedVR to 2160p, about $0.008 per background) → `assets/img4k/`. Crop to
  3840x2160 webp in `web/a4k/`, copy `index.html` to `index4k.html` with `a/bg_` → `a4k/bg_`, then
  `PAGE=web/index4k.html DPR=2 OUT=render/frames4k RESUME=1 timeout 570 node render.cjs frames 30 2`. One 570 s
  part does about 750 frames, so a 95 s video needs 4 parts (delete the 4 newest frames before each resume).
  Cut-outs of about 1000 px height stay sharp at 4K without an upscale. 4K JPEG frames are about 1.2 MB each.
  Encode in segments of about 950 frames (`-start_number`, `-frames:v`, about 3 min each with `-threads 2`), join
  with the concat demuxer (`-c:v copy`) and add the audio. CRF 18 gives about 200 MB for 95 s.
- **Vertical 1080x1920:** new vertical backgrounds from Codex ("tall vertical 9:16 portrait image, empty middle and
  lower area for characters"), then a new layout. `examples/frp_make_vertical.py` changes the stage size, CSS
  (caption, lanes, end card) and the transition, and pastes in `examples/frp_two_tracks_clay_vertical_scenes.js`.
  Instagram safe zones: no text in the top ~220 px or the bottom ~300 px (caption `bottom: 300px`), feet at y ~1450,
  chips max ~920 px wide (Rubik Mono chip width ≈ 1.2 × size × letters, so split long titles into two chips).
  Re-measure map roads on the new image (sample the road color per row, see the s2 points in the example).
  Render: `PAGE=web/indexv.html VW=1080 VH=1920 OUT=render/framesv node render.cjs frames 30 2` (same time as 1080p).
  Instagram converts Reels to 1080 wide, so 4K is only useful for the 16:9 version.

## Delivering big files on Telegram

The Bot API takes max 50 MB per file. Kitan watches on the phone: send **video files, not a zip**, at full quality.
- A file a little over 50 MB: encode again at the same CRF with `-preset slow` (52 MB → 49.5 MB at CRF 19).
- A bigger file (4K): cut it without re-encode into parts under 49 MB at keyframes
  (`ffmpeg -i in.mp4 -map 0 -c copy -f segment -segment_times 16.7,31.7,... -reset_timestamps 1 part%d.mp4`),
  name them `part1_of_6` and so on, and keep the single file on the server. A one-file download needs a Caddy route; ask first.
- Do not use `zip -s` (Info-ZIP split archives failed the CRC test after re-join), and phones cannot open split zips.

## Other styles

The engine is only a page with `window.seek(t)` and `window.TOTAL`; `render.cjs` works with any such page.
Example: `~/tank-orin/web/index.html` is a 16-bit pixel-art video that replays a real game frame by frame,
with chiptune SFX synthesized locally (`synth.py`) and placed from the game's own events (`events.js`, `mix.py`).

## Prices (fal list prices)

| What | Model | Price |
|---|---|---|
| Voice | `fal-ai/elevenlabs/tts/eleven-v3` | $0.10 / 1000 chars |
| SFX | `fal-ai/elevenlabs/sound-effects/v2` | $0.002 / s |
| Music | `fal-ai/elevenlabs/music` | $0.60 / min (the biggest cost: reuse tracks) |
| Cut-out | `fal-ai/birefnet/v2` | < $0.01 / image |
| Image (fallback) | `fal-ai/nano-banana-2`, `/edit` (`python fal_image.py`) | $0.08 / image |
| Pronunciation check | `fal-ai/whisper` (audio as a data URI) | about $0.001 / clip |

## Gotchas

- `render.cjs` loads Playwright from `~/.claude/skills/gstack/node_modules/playwright`.
- Layers: hide whole scenes with `display`, not `visibility`; a child set to `visible` shows through a hidden parent.
- `prep.py` takes word times from the voice clips. After you change a scene's text, regenerate that clip and re-run `prep.py`.
- A batch of stills can hang once at browser start. Run them one per call with `timeout 60` (2-6 s each) if that happens.
- With 3840x2160 backgrounds, `img.decode()` can fail once when two scenes share one image. `READY` now tries a second time.
- `python fal.py cost` gets HTTP 429 from the pricing API after many calls. Wait a few minutes and run it again.
- `pkill -f <pattern>` inside a command line that contains the same pattern kills its own shell. Stop a render by PID
  (`ps -eo pid,args | grep "[r]ender.cjs frames"`).
