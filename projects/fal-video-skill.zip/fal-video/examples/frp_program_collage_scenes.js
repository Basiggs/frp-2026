// FRP 2026 AI Engineering promo (paper collage, 11 scenes, 8-day strip, road map): ~/frp-video
// Example scene code for template/web/index.html: replace the BG map and the defScene(...) blocks,
// and add the CSS below inside <style>. Final code as rendered (layout fixes included).

/* ---- CSS to add ----
.strip { position: absolute; left: 360px; top: 34px; width: 1200px; height: 80px; }
.strip .line { position: absolute; left: 30px; right: 30px; top: 37px; height: 6px; background: repeating-linear-gradient(90deg, #253a63 0 22px, transparent 22px 34px); opacity: .7; }
.stn { position: absolute; width: 64px; height: 64px; margin: -32px 0 0 -32px; border-radius: 50%; display: grid; place-items: center;
  font: 30px "Rubik Mono One", sans-serif; background: #f6f0e1; color: #253a63; border: 5px solid #253a63; box-shadow: 4px 6px 0 rgba(20,12,6,.35); }
.stn.past { background: #2f7f7a; color: #f6f0e1; border-color: #2f7f7a; }
.stn.now { background: #d9a23a; color: #2b2420; border-color: #b5452f; box-shadow: 0 0 26px rgba(255,200,60,.95), 4px 6px 0 rgba(20,12,6,.35); }
.mapstn { position: absolute; width: 86px; height: 86px; margin: -43px 0 0 -43px; border-radius: 50%; display: grid; place-items: center;
  font: 40px "Rubik Mono One", sans-serif; background: #d9a23a; color: #2b2420; border: 6px solid #b5452f; box-shadow: 5px 8px 0 rgba(20,12,6,.4); }
.maplbl { position: absolute; transform: translateX(-50%); white-space: nowrap; font: 30px "Rubik Mono One", sans-serif; color: #253a63;
  background: #f6f0e1; padding: 8px 14px 6px; box-shadow: 4px 6px 0 rgba(20,12,6,.3); }
.endcard { position: absolute; left: 960px; top: 300px; transform-origin: 50% 50%; background: #f3ead6; padding: 34px 60px 30px; text-align: center; color: #1c2a4a;
  box-shadow: 10px 14px 0 rgba(20,12,6,.35); clip-path: polygon(0 3%, 6% 0, 30% 2%, 55% 0, 80% 3%, 100% 0, 99% 40%, 100% 97%, 70% 100%, 45% 98%, 20% 100%, 0 97%, 1% 50%); }
.endcard .t1 { font: 74px/1.05 "Rubik Mono One", sans-serif; color: #b5452f; }
.endcard .t2 { font: 40px/1.2 "Rubik Mono One", sans-serif; margin-top: 10px; }
.endcard .t3 { font: 46px/1.2 "Patrick Hand", sans-serif; margin-top: 14px; color: #2f7f7a; }
---- end CSS ---- */

const BG = { s1: "nu", s2: "map", s3: "senate", s4: "server", s5: "office", s6: "nu", s7: "office", s8: "server", s9: "office", s10: "stage", s11: "nu" };

// ---------- FRP 2026: shared pieces ----------
const DAYS = ["OPENING", "AI + AGENTS", "HEAR + SPEAK", "SEE", "TEST", "LEARN", "SHARE", "DEMO DAY"];
function dayStrip(L, n) {  // 8 connected stations at the top, day n lit
  const box = el("div", "strip", L); el("div", "line", box);
  const st = DAYS.map((_, i) => { const e = el("div", "stn" + (i + 1 < n ? " past" : i + 1 === n ? " now" : ""), box, String(i + 1));
    e.style.left = (30 + i * (1140 / 7)) + "px"; e.style.top = "40px"; return e; });
  return (t) => { st.forEach((e, i) => { const a = .05 + i * .04; e.style.scale = t < a ? 0 : eOutBack(P(t, a, .3)) * (i + 1 === n ? 1.25 + Math.sin(t * 5) * .06 : 1); }); };
}
function dayChips(L, n, sid, topic) {
  const day = new Chip(L, `DAY ${n}`, 960, 205, 92, 100 + n, { rot: -3, font: '"Rubik Mono One"' });
  const top = new Chip(L, topic || DAYS[n - 1], 960, 330, 58, 200 + n, { rot: 2, font: '"Rubik Mono One"' });
  return (t) => { day.set(t, wt(sid, "Day") - .15); top.set(t, wt(sid, "Day") + .45); };
}
function emoji(L, ch, x, y, size) {
  const e = el("div", "emo", L, ch); Object.assign(e.style, { position: "absolute", left: x + "px", top: y + "px", fontSize: size + "px" }); e.style.visibility = "hidden";
  return (t, a) => { e.style.visibility = t >= a ? "visible" : "hidden"; e.style.scale = t >= a ? eOutBack(P(t, a, .35)) : 0; e.style.rotate = (Math.sin(t * 3 + x) * 6) + "deg"; };
}
const pop = (c, t, a, extra = {}) => { const p = placeIn(t, a); c.set(t, { ...p, ...extra, dy: (p.dy || 0) + (extra.dy || 0) }); };

// ---------- scenes ----------
defScene("s1", (L, s) => {
  const studs = new Cut(L, "students", 1480, 1030, 440), robot = new Cut(L, "robot", 360, 1010, 230);
  const issai = new Chip(L, "ISSAI", 960, 170, 120, 3, { rot: -3, font: '"Rubik Mono One"' });
  const frp = new Chip(L, "FALL RESEARCH PROGRAM 2026", 960, 320, 56, 5, { rot: 2, font: '"Rubik Mono One"' });
  const nu = paperTag(L, '<span class="mono">NAZARBAYEV UNIVERSITY, ASTANA</span>', 120, 430, { size: 40, rot: -3 });
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.12, y0: 0, y1: -20 });
    showTag(nu, t, wt("s1", "Nazarbayev") - .1);
    issai.set(t, wt("s1", "ISSAI") - .15); frp.set(t, wt("s1", "Fall") - .1);
    pop(studs, t, wt("s1", "opens") - .1); pop(robot, t, wt("s1", "doors"), { r: Math.sin(t * 4) * 4 });
  } };
});

defScene("s2", (L, s) => {
  const XS = [138, 379, 620, 861, 1102, 1343, 1584, 1825], YS = [385, 471, 540, 597, 511, 522, 534, 522];
  const st = XS.map((x, i) => { const e = el("div", "mapstn", L, String(i + 1)); Object.assign(e.style, { left: x + "px", top: YS[i] + "px" }); e.style.visibility = "hidden"; return e; });
  const lb = XS.map((x, i) => { const e = el("div", "maplbl", L, DAYS[i]); Object.assign(e.style, { left: Math.min(1780, Math.max(140, x)) + "px", top: (YS[i] + (i % 2 ? 70 : -125)) + "px" }); e.style.visibility = "hidden"; return e; });
  const robot = new Cut(L, "robot", 0, 0, 150);
  const head = new Chip(L, "8 DAYS", 960, 115, 90, 9, { rot: -4, font: '"Rubik Mono One"' });
  const track = new Chip(L, "AI ENGINEERING TRACK", 960, 245, 46, 10, { rot: 3, font: '"Rubik Mono One"' });
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.0 });
    head.set(t, wt("s2", "Eight") - .1); track.set(t, wt("s2", "AI") - .1);
    const a0 = wt("s2", "Here") - .6, step = (wt("s2", "step", 1) + .2 - a0) / 8;
    st.forEach((e, i) => { const a = a0 + i * step; e.style.visibility = t >= a ? "visible" : "hidden"; e.style.scale = t >= a ? eOutBack(P(t, a, .35)) : 0; });
    lb.forEach((e, i) => { const a = a0 + i * step + .15; e.style.visibility = t >= a ? "visible" : "hidden"; e.style.scale = t >= a ? eOutBack(P(t, a, .3)) : 0; e.style.rotate = ((i % 2 ? 2 : -2) + boil(i, t).r) + "deg"; });
    const k = clamp((t - a0) / (8 * step + .4)), f = k * 7, i0 = Math.min(6, Math.floor(f)), fr = f - i0;
    robot.x = lerp(XS[i0], XS[i0 + 1], fr); robot.y = lerp(YS[i0], YS[i0 + 1], fr) + 10;
    robot.set(t, { s: t >= a0 - .3 ? 1 : 0, dy: -Math.abs(Math.sin(t * 9)) * 14, r: Math.sin(t * 9) * 5 });
  } };
});

defScene("s3", (L, s) => {
  const strip = dayStrip(L, 1), chips = dayChips(L, 1, "s3");
  const studs = new Cut(L, "students", 520, 1060, 430), pizza = new Cut(L, "pizza", 1480, 1010, 300);
  const wel = new Chip(L, "WELCOME!", 980, 470, 84, 31, { rot: -2, font: '"Rubik Mono One"' });
  const e1 = emoji(L, "🍕", 1640, 640, 110), e2 = emoji(L, "👋", 250, 560, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.08, s1: 1.0 });
    strip(t); chips(t); wel.set(t, wt("s3", "Welcome") - .1);
    pop(studs, t, wt("s3", "Meet") - .2); e2(t, wt("s3", "mentors"));
    pop(pizza, t, wt("s3", "pizza") - .25, { r: Math.sin(t * 6) * 3 }); e1(t, wt("s3", "pizza") + .2);
  } };
});

defScene("s4", (L, s) => {
  const strip = dayStrip(L, 2), chips = dayChips(L, 2, "s4");
  const gpu = new Cut(L, "gpu", 1450, 1010, 470), coder = new Cut(L, "coder", 470, 1030, 380), robot = new Cut(L, "robot", 920, 1010, 210);
  const think = new Chip(L, "HOW DOES AI THINK?", 960, 455, 56, 41, { rot: -2, font: '"Rubik Mono One"' });
  const gp = paperTag(L, '<span class="mono">ISSAI SUPERCOMPUTER</span>', 1180, 470, { size: 36, rot: 3 });
  const e1 = emoji(L, "💡", 900, 610, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.05, s1: 1.14 });
    strip(t); chips(t); think.set(t, wt("s4", "How") - .1, { out: wt("s4", "Students") + .3 });
    pop(coder, t, wt("s4", "Students") - .1);
    pop(gpu, t, wt("s4", "supercomputer") - .4, { boil: .5 }); showTag(gp, t, wt("s4", "supercomputer"));
    pop(robot, t, wt("s4", "choose") - .1, { r: Math.sin(t * 5) * 5 }); e1(t, wt("s4", "project") - .1);
  } };
});

defScene("s5", (L, s) => {
  const strip = dayStrip(L, 3), chips = dayChips(L, 3, "s5");
  const spk = new Cut(L, "speaker", 560, 1030, 440), robot = new Cut(L, "robot", 1450, 1010, 250);
  const kz = new Chip(L, "IN KAZAKH TOO!", 1350, 470, 58, 51, { rot: 3, font: '"Rubik Mono One"' });
  const e1 = emoji(L, "🎤", 880, 560, 100), e2 = emoji(L, "🔊", 1100, 640, 90), e3 = emoji(L, "✨", 1600, 600, 90);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.04 });
    strip(t); chips(t);
    pop(spk, t, wt("s5", "hears") - .3); e1(t, wt("s5", "hears")); e2(t, wt("s5", "speaks"));
    kz.set(t, wt("s5", "Kazakh") - .1);
    pop(robot, t, wt("s5", "first") - .2, { r: Math.sin(t * 6) * 6, dy: -Math.abs(Math.sin(t * 7)) * 10 }); e3(t, wt("s5", "life") - .1);
  } };
});

defScene("s6", (L, s) => {
  const strip = dayStrip(L, 4), chips = dayChips(L, 4, "s6");
  const cam = new Cut(L, "camera", 1380, 1020, 440), coder = new Cut(L, "coder", 470, 1040, 360);
  const e1 = emoji(L, "📷", 960, 520, 100), e2 = emoji(L, "🐈", 760, 660, 90), e3 = emoji(L, "🌳", 1000, 700, 90), e4 = emoji(L, "🌍", 1180, 600, 90);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.15, s1: 1.05, x0: -40, x1: 30 });
    strip(t); chips(t);
    pop(cam, t, wt("s6", "sees") - .1); e1(t, wt("s6", "Photos")); e2(t, wt("s6", "cameras")); e3(t, wt("s6", "world")); e4(t, wt("s6", "around"));
    pop(coder, t, wt("s6", "AI") - .1);
  } };
});

defScene("s7", (L, s) => {
  const strip = dayStrip(L, 5), chips = dayChips(L, 5, "s7", "WHEN IS AI WRONG?");
  const chart = new Cut(L, "chart", 1380, 1020, 460), robot = new Cut(L, "robot", 560, 1010, 250);
  const w = [["TEST", 330, 470], ["MEASURE", 600, 580], ["IMPROVE", 900, 690]].map(([tx, x, y], i) => new Chip(L, tx, x, y, 52, 72 + i, { rot: i % 2 ? 3 : -3, font: '"Rubik Mono One"' }));
  const e1 = emoji(L, "✅", 1600, 560, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.04, s1: 1.12, x0: 20, x1: -20 });
    strip(t); chips(t);
    pop(chart, t, wt("s7", "test") - .3); pop(robot, t, wt("s7", "Students") - .1, { flip: true, r: Math.sin(t * 5) * 4 });
    w[0].set(t, wt("s7", "test") - .05); w[1].set(t, wt("s7", "measure") - .05); w[2].set(t, wt("s7", "better") - .1); e1(t, wt("s7", "better"));
  } };
});

defScene("s8", (L, s) => {
  const strip = dayStrip(L, 6), chips = dayChips(L, 6, "s8");
  const brain = new Cut(L, "brain", 960, 1010, 430);
  const w = [["DATA", 330, 640], ["TRAINING", 960, 470], ["SMARTER MODELS", 1460, 640]].map(([tx, x, y], i) => new Chip(L, tx, x, y, 54, 81 + i, { rot: i % 2 ? -2 : 3, font: '"Rubik Mono One"' }));
  const e1 = emoji(L, "📚", 260, 760, 100), e2 = emoji(L, "🚀", 1620, 760, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.14, s1: 1.04 });
    strip(t); chips(t);
    pop(brain, t, wt("s8", "learn") - .3, { s: 1 + Math.sin(t * 4) * .02, boil: .6 });
    w[0].set(t, wt("s8", "data") - .1); e1(t, wt("s8", "data"));
    w[1].set(t, wt("s8", "training") - .1);
    w[2].set(t, wt("s8", "smarter") - .1); e2(t, wt("s8", "smarter") + .1);
  } };
});

defScene("s9", (L, s) => {
  const strip = dayStrip(L, 7), chips = dayChips(L, 7, "s9");
  const paper = new Cut(L, "paper", 1380, 1010, 380), coder = new Cut(L, "coder", 480, 1040, 360);
  const w = [["PAPER", 1150, 470], ["PROJECT PAGE", 1300, 585], ["TALK", 700, 480]].map(([tx, x, y], i) => new Chip(L, tx, x, y, 52, 91 + i, { rot: i % 2 ? 3 : -3, font: '"Rubik Mono One"' }));
  const e1 = emoji(L, "🌐", 1760, 660, 90), e2 = emoji(L, "🎙️", 760, 650, 90);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.06, s1: 1.14, x0: -20, x1: 20 });
    strip(t); chips(t); pop(coder, t, wt("s9", "Day") + .3);
    pop(paper, t, wt("s9", "research") - .2); w[0].set(t, wt("s9", "paper") - .1);
    w[1].set(t, wt("s9", "project") - .1); e1(t, wt("s9", "page"));
    w[2].set(t, wt("s9", "talk") - .2); e2(t, wt("s9", "talk"));
  } };
});

defScene("s10", (L, s) => {
  const strip = dayStrip(L, 8), chips = dayChips(L, 8, "s10");
  const pres = new Cut(L, "presenter", 1300, 1020, 520), studs = new Cut(L, "students", 470, 1080, 380);
  const conf = hearts(L, 70);
  const e1 = emoji(L, "🎉", 1650, 470, 110), e2 = emoji(L, "👏", 820, 600, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.1 });
    strip(t); chips(t);
    pop(pres, t, wt("s10", "Demo") - .2, { r: Math.sin(t * 3) * 2 }); e1(t, wt("s10", "Demo") + .3);
    pop(studs, t, wt("s10", "family") - .3, { dy: -Math.abs(Math.sin(t * 6)) * 12 }); e2(t, wt("s10", "friends"));
    conf(t, clamp((t - wt("s10", "Demo")) / .6));
  } };
});

defScene("s11", (L, s) => {
  const studs = new Cut(L, "students", 470, 1040, 420), robot = new Cut(L, "robot", 1000, 1020, 240), robot2 = new Cut(L, "robot", 1450, 1020, 200, 77);
  const lead = new Chip(L, "STUDENTS LEAD AI AGENTS", 960, 180, 64, 111, { rot: -2, font: '"Rubik Mono One"' });
  const fast = new Chip(L, "BUILD A LOT IN 8 DAYS", 960, 320, 54, 112, { rot: 2, font: '"Rubik Mono One"' });
  const card = el("div", "endcard", L, '<div class="t1">ISSAI FRP 2026</div><div class="t2">AI ENGINEERING TRACK</div><div class="t3">24-31 October, Nazarbayev University</div>');
  card.style.visibility = "hidden";
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.0, y0: -20, y1: 0 });
    pop(studs, t, wt("s11", "Students") - .2);
    pop(robot, t, wt("s11", "agents") - .3, { r: Math.sin(t * 5) * 5, dy: -Math.abs(Math.sin(t * 8)) * 12 });
    pop(robot2, t, wt("s11", "agents") - .1, { r: Math.sin(t * 6 + 1) * 6, dy: -Math.abs(Math.sin(t * 8 + 1)) * 12 });
    const c = wt("s11", "ISSAI") - .2;
    lead.set(t, wt("s11", "lead") - .1, { out: c }); fast.set(t, wt("s11", "build") - .1, { out: c });
    card.style.visibility = t >= c ? "visible" : "hidden";
    const k = eOutBack(P(t, c, .45)); card.style.transform = `translate(-50%, 0) rotate(${-2 + boil(9, t).r}deg) scale(${k})`;
  } };
});


