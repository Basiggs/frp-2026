// 1080x1920 layout. Instagram safe zones: top ~220 px (header), bottom ~300 px (caption is above it), right edge icons.
// Characters stand with their feet at y ~1450, the caption sits below them.
defScene("s1", (L, s) => {
  const studs = new Cut(L, "students", 640, 1450, 540), mascot = new Cut(L, "mascot", 200, 1430, 260);
  const issai = badge(L, "ISSAI", 540, 330, 120, 3);
  const frp1 = badge(L, "FALL RESEARCH", 540, 470, 58, 5), frp2 = badge(L, "PROGRAM 2026", 540, 575, 58, 6);
  const nu = paperTag(L, '<span class="mono">NAZARBAYEV UNIVERSITY<br>ASTANA</span>', 80, 680, { size: 36, rot: -3 });
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.1, y0: 0, y1: -30 });
    issai.set(t, wt("s1", "ISSAI") - .15); frp1.set(t, wt("s1", "research") - .1); frp2.set(t, wt("s1", "research") + .2);
    showTag(nu, t, wt("s1", "Nazarbayev") - .1);
    pop(studs, t, wt("s1", "students") - .2); pop(mascot, t, wt("s1", "opens"), { r: Math.sin(t * 4) * 4 });
  } };
});

defScene("s2", (L, s) => {  // road points measured on bgv_map at 1080x1920 (bottom = university, top = Demo Day stage)
  const TEALR = [[432, 1430], [406, 1350], [370, 1270], [392, 1190], [404, 1110], [413, 1030], [370, 990], [272, 910], [246, 830], [273, 790], [352, 750], [452, 670], [437, 590], [389, 510], [376, 470], [428, 430], [484, 390], [472, 310], [482, 270], [523, 230]];
  const CORALR = [[590, 1430], [658, 1390], [694, 1350], [683, 1270], [668, 1230], [691, 1150], [721, 1110], [770, 1030], [771, 950], [708, 910], [676, 830], [730, 790], [796, 710], [810, 630], [792, 590], [726, 550], [667, 470], [658, 430], [700, 390], [712, 350], [656, 310], [597, 270]];
  const head = badge(L, "8 DAYS", 220, 560, 56, 9), paths = badge(L, "2 PATHS", 220, 690, 48, 10);
  const ai = badge(L, "AI ENGINEERING", 360, 1060, 38, 11, TEAL), rob = badge(L, "ROBOTICS", 880, 1180, 40, 12, CORAL);
  const demo = badge(L, "DEMO DAY", 540, 250, 40, 13);
  const mascot = new Cut(L, "mascot", 0, 0, 110), drone = new Cut(L, "drone", 0, 0, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.0 });
    head.set(t, wt("s2", "Eight") - .1); paths.set(t, wt("s2", "paths") - .1);
    ai.set(t, wt("s2", "AI") - .1); rob.set(t, wt("s2", "Robotics") - .1); demo.set(t, wt("s2", "move") - .1);
    const ka = P(t, wt("s2", "AI"), 3.2), kr = P(t, wt("s2", "Robotics"), 2.6);
    [mascot.x, mascot.y] = along(TEALR, ka); mascot.y += 8; mascot.set(t, { s: t >= wt("s2", "AI") - .1 ? 1 : 0, dy: -Math.abs(Math.sin(t * 9)) * 10 });
    [drone.x, drone.y] = along(CORALR, kr); drone.y -= 30; drone.set(t, { s: t >= wt("s2", "Robotics") - .1 ? 1 : 0, r: Math.sin(t * 7) * 6, boil: .5 });
  } };
});

defScene("s3", (L, s) => {
  const ln = lanes(L, [1], "both"), studs = new Cut(L, "students", 600, 1450, 520), mascot = new Cut(L, "mascot", 180, 1430, 240);
  const day = badge(L, "DAY 1", 540, 470, 90, 21), all = badge(L, "FOR EVERYONE", 540, 600, 52, 22);
  const e1 = emoji(L, "🍕", 870, 900, 100), e2 = emoji(L, "🎉", 60, 860, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.08, s1: 1.0 }); ln(t);
    day.set(t, wt("s3", "Day") - .15); all.set(t, wt("s3", "everyone") - .1);
    pop(studs, t, wt("s3", "opening") - .2); e2(t, wt("s3", "ceremony")); pop(mascot, t, wt("s3", "tour") - .2, { r: Math.sin(t * 5) * 5 });
    e1(t, wt("s3", "pizza"));
  } };
});

defScene("s4", (L, s) => {
  const ln = lanes(L, [2, 3, 4, 5, 6, 7], "ai"), coder = new Cut(L, "coder", 300, 1450, 520), mascot = new Cut(L, "mascot", 800, 1430, 320);
  const tr = badge(L, "AI TRACK", 540, 470, 84, 31, TEAL), ag = badge(L, "LEAD AI AGENTS", 540, 600, 50, 32);
  const sc = paperTag(L, '<span class="mono">ISSAI SUPERCOMPUTER</span>', 300, 700, { size: 34, rot: 3 });
  const e1 = emoji(L, "🧠", 560, 860, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.05, s1: 1.14 }); ln(t);
    tr.set(t, wt("s4", "AI") - .15); pop(coder, t, wt("s4", "students") - .2); e1(t, wt("s4", "thinks"));
    ag.set(t, wt("s4", "lead") - .1); pop(mascot, t, wt("s4", "agents") - .2, { r: Math.sin(t * 5) * 5 });
    showTag(sc, t, wt("s4", "supercomputer") - .1);
  } };
});

defScene("s5", (L, s) => {
  const ln = lanes(L, [1, 2, 3], "rob"), maker = new Cut(L, "maker", 260, 1450, 520), printer = new Cut(L, "printer", 740, 1440, 400);
  const tr = badge(L, "ROBOTICS TRACK", 540, 470, 52, 41, CORAL), cad = badge(L, "CAD + ARDUINO", 540, 590, 50, 42);
  const e1 = emoji(L, "⚡", 420, 960, 100), e2 = emoji(L, "⚙️", 820, 840, 90);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.04 }); ln(t);
    tr.set(t, wt("s5", "robotics") - .15); pop(printer, t, wt("s5", "design") - .2); cad.set(t, wt("s5", "CAD") - .1);
    pop(maker, t, wt("s5", "wire") - .2); e1(t, wt("s5", "Arduino")); e2(t, wt("s5", "motors"));
  } };
});

defScene("s6", (L, s) => {
  const ln = lanes(L, [4, 5, 6, 7], "ai"), senses = new Cut(L, "senses", 760, 1450, 440), coder = new Cut(L, "coder", 250, 1450, 470);
  const tr = badge(L, "AI PROJECTS", 540, 460, 62, 51, TEAL);
  const w = [["HEAR", 230, 610], ["SPEAK", 540, 700], ["SEE", 850, 610]].map(([tx, x, y], i) => badge(L, tx, x, y, 54, 52 + i));
  const kz = paperTag(L, '<span class="mono">KAZAKH SPEECH</span>', 330, 800, { size: 34, rot: -2 });
  const e1 = emoji(L, "🌍", 860, 880, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.04, x0: 15, x1: -15 }); ln(t);
    tr.set(t, wt("s6", "AI") - .15); pop(coder, t, wt("s6", "projects") - .1);
    w[0].set(t, wt("s6", "hear") - .1); w[1].set(t, wt("s6", "speak") - .1); w[2].set(t, wt("s6", "see") - .1);
    pop(senses, t, wt("s6", "voice") - .2); showTag(kz, t, wt("s6", "Kazakh") - .1); e1(t, wt("s6", "world"));
  } };
});

defScene("s7", (L, s) => {
  const ln = lanes(L, [4, 5, 6, 7], "rob"), drone = new Cut(L, "drone", 0, 0, 230);
  const tr1 = badge(L, "ROBOTICS", 540, 460, 72, 61, CORAL), tr2 = badge(L, "PROJECTS", 540, 570, 72, 63, CORAL), f8 = badge(L, "FIGURE 8!", 540, 690, 60, 62);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.08 }); ln(t);
    tr1.set(t, wt("s7", "Robotics") - .15); tr2.set(t, wt("s7", "projects") - .1); f8.set(t, wt("s7", "figure") - .1);
    const a = wt("s7", "off") - .2, u = Math.max(0, t - a) * 1.6;  // take off, then a figure-eight (lemniscate) in the air
    const lift = eOutCubic(P(t, a, .8));
    drone.x = 540 + 330 * Math.sin(u) * lift; drone.y = lerp(1450, 1150, lift) + 170 * Math.sin(u) * Math.cos(u) * lift;
    drone.set(t, { s: t >= a - .2 ? 1 : 0, r: Math.cos(u) * 12 * lift, boil: .4 });
  } };
});

defScene("s8", (L, s) => {
  const ln = lanes(L, [4, 5, 6, 7], "rob"), soft = new Cut(L, "softrobot", 270, 1450, 580), arm = new Cut(L, "arm", 780, 1450, 500);
  const b1 = badge(L, "SOFT ROBOT", 540, 470, 54, 71, CORAL), b2 = badge(L, "ROBOTIC ARM", 540, 590, 54, 72, CORAL);
  const e1 = emoji(L, "🐘", 470, 790, 100), e2 = emoji(L, "📦", 640, 880, 90);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.06, s1: 1.12 }); ln(t);
    pop(soft, t, wt("s8", "soft") - .2, { r: Math.sin(t * 2.2) * 9 }); b1.set(t, wt("s8", "soft") - .1); e1(t, wt("s8", "elephant"));
    pop(arm, t, wt("s8", "robotic") - .2, { r: Math.sin(t * 3) * 5 }); b2.set(t, wt("s8", "robotic") - .1); e2(t, wt("s8", "pick"));
  } };
});

defScene("s9", (L, s) => {
  const ln = lanes(L, [5, 6, 7], "both"), maker = new Cut(L, "maker", 270, 1450, 500), mascot = new Cut(L, "mascot", 780, 1430, 320);
  const both = badge(L, "BOTH TRACKS", 540, 460, 64, 81);
  const w = [["TEST", 230, 600], ["MEASURE", 540, 710], ["IMPROVE", 810, 820]].map(([tx, x, y], i) => badge(L, tx, x, y, 54, 82 + i));
  const e1 = emoji(L, "📈", 860, 980, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.04, s1: 1.12 }); ln(t);
    both.set(t, wt("s9", "both") - .15); pop(maker, t, wt("s9", "students") - .2); pop(mascot, t, wt("s9", "students"), { r: Math.sin(t * 5) * 5 });
    w[0].set(t, wt("s9", "test") - .1); w[1].set(t, wt("s9", "measure") - .1); w[2].set(t, wt("s9", "improve") - .1); e1(t, wt("s9", "engineers"));
  } };
});

defScene("s10", (L, s) => {
  const ln = lanes(L, [8], "both"), pres = new Cut(L, "presenter", 770, 1450, 580), drone = new Cut(L, "drone", 0, 0, 150), arm = new Cut(L, "arm", 280, 1450, 400);
  const day = badge(L, "DAY 8", 540, 460, 90, 91), demo = badge(L, "DEMO DAY!", 540, 580, 66, 92);
  const conf = hearts(L, 60), e1 = emoji(L, "👏", 470, 990, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.1 }); ln(t);
    day.set(t, wt("s10", "Day") - .15); demo.set(t, wt("s10", "Demo") - .1);
    const u = t * 1.4; drone.x = 540 + 360 * Math.sin(u); drone.y = 880 + 80 * Math.sin(2 * u);
    drone.set(t, { s: t >= wt("s10", "Drones") - .2 ? 1 : 0, r: Math.cos(u) * 10, boil: .4 });
    pop(arm, t, wt("s10", "robots") - .2, { r: Math.sin(t * 3) * 6 });
    pop(pres, t, wt("s10", "talk") - .3, { r: Math.sin(t * 3) * 2 }); e1(t, wt("s10", "friends"));
    conf(t, clamp((t - wt("s10", "Demo")) / .6));
  } };
});

defScene("s11", (L, s) => {
  const studs = new Cut(L, "students", 330, 1450, 500), mascot = new Cut(L, "mascot", 810, 1440, 290), drone = new Cut(L, "drone", 0, 0, 140);
  const two = badge(L, "TWO TRACKS", 540, 330, 64, 101), goal = badge(L, "ONE GOAL", 540, 440, 64, 103);
  const real1 = badge(L, "BUILD SOMETHING", 540, 570, 50, 102), real2 = badge(L, "REAL", 540, 680, 72, 104);
  const card = el("div", "endcard", L, '<div class="t1">ISSAI FRP 2026</div><div class="t2">AI ENGINEERING<br>+ ROBOTICS</div><div class="t3">24-31 October<br>Nazarbayev University, Astana</div>');
  card.style.visibility = "hidden";
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.0, y0: -20, y1: 0 });
    const c = wt("s11", "Join") - .1;
    two.set(t, wt("s11", "Two") - .1, { out: c }); goal.set(t, wt("s11", "goal") - .1, { out: c });
    real1.set(t, wt("s11", "build") - .1, { out: c }); real2.set(t, wt("s11", "real") - .1, { out: c });
    pop(studs, t, wt("s11", "tracks") - .1); pop(mascot, t, wt("s11", "goal") - .2, { r: Math.sin(t * 5) * 5, dy: -Math.abs(Math.sin(t * 8)) * 10 });
    const u = t * 1.2; drone.x = 800 + 150 * Math.sin(u); drone.y = 1020 + 50 * Math.sin(2 * u); drone.set(t, { s: t >= wt("s11", "real") ? 1 : 0, r: Math.cos(u) * 8, boil: .4 });
    card.style.visibility = t >= c ? "visible" : "hidden";
    card.style.transform = `translate(-50%, 0) rotate(${-2 + boil(9, t).r}deg) scale(${eOutBack(P(t, c, .45))})`;
  } };
});
