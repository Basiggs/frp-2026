// FRP 2026 AI Engineering + Robotics promo (3D clay, 11 scenes, two-lane strip, movers on a measured road, figure-eight drone): ~/frp-mix-video
// Example scene code for template/web/index.html: replace the BG map and the defScene(...) blocks,
// and add the CSS below inside <style>. Final code as rendered (layout fixes included).

/* ---- CSS to add ----
.lanes { position: absolute; left: 300px; top: 22px; width: 1320px; height: 116px; }
.lane { position: absolute; left: 0; width: 1320px; height: 52px; }
.lane .lbl { position: absolute; left: 0; top: 4px; width: 200px; text-align: center; font: 24px "Rubik Mono One", sans-serif; color: #f6f0e1; padding: 8px 0 6px; box-shadow: 3px 5px 0 rgba(20,12,6,.3); }
.lane .lbl.ai { background: #2f7f7a; } .lane .lbl.rob { background: #b5452f; }
.lane .dot { position: absolute; top: 2px; width: 46px; height: 46px; border-radius: 50%; display: grid; place-items: center; font: 22px "Rubik Mono One", sans-serif;
  background: #f6f0e1; color: #253a63; border: 4px solid #253a63; box-shadow: 3px 5px 0 rgba(20,12,6,.3); }
.lane .dot.off { opacity: .45; }
.lane .dot.on.ai { background: #2f7f7a; color: #f6f0e1; border-color: #f6f0e1; box-shadow: 0 0 22px rgba(80,220,200,.9), 3px 5px 0 rgba(20,12,6,.3); }
.lane .dot.on.rob { background: #b5452f; color: #f6f0e1; border-color: #f6f0e1; box-shadow: 0 0 22px rgba(255,140,110,.9), 3px 5px 0 rgba(20,12,6,.3); }
.endcard { position: absolute; left: 960px; top: 290px; transform-origin: 50% 50%; background: #f3ead6; padding: 34px 60px 30px; text-align: center; color: #1c2a4a;
  box-shadow: 10px 14px 0 rgba(20,12,6,.35); clip-path: polygon(0 3%, 6% 0, 30% 2%, 55% 0, 80% 3%, 100% 0, 99% 40%, 100% 97%, 70% 100%, 45% 98%, 20% 100%, 0 97%, 1% 50%); }
.endcard .t1 { font: 74px/1.05 "Rubik Mono One", sans-serif; color: #b5452f; }
.endcard .t2 { font: 40px/1.2 "Rubik Mono One", sans-serif; margin-top: 10px; color: #2f7f7a; }
.endcard .t3 { font: 44px/1.2 "Patrick Hand", sans-serif; margin-top: 14px; }
---- end CSS ---- */

const BG = { s1: "campus", s2: "map", s3: "hall", s4: "ailab", s5: "workshop", s6: "ailab", s7: "arena", s8: "workshop", s9: "arena", s10: "stage", s11: "campus" };

// ---------- FRP mix: shared pieces ----------
const TEAL = ["#2f7f7a"], CORAL = ["#b5452f"];
function lanes(L, days, which) {  // two rows of 8 days: AI (teal) and ROBOTICS (coral); days[] lit for the active track(s)
  const box = el("div", "lanes", L);
  const rows = [["ai", "AI", 0], ["rob", "ROBOTICS", 1]].map(([k, name, r]) => {
    const row = el("div", "lane", box); row.style.top = (r * 58) + "px";
    el("div", "lbl " + k, row, name);
    const on = which === "both" || which === k;
    const dots = [...Array(8)].map((_, i) => { const d = el("div", "dot" + (on && days.includes(i + 1) ? " on " + k : on ? "" : " off"), row, String(i + 1)); d.style.left = (230 + i * 112) + "px"; return d; });
    return dots;
  });
  return (t) => rows.flat().forEach((d, i) => { const a = .05 + (i % 8) * .03; d.style.scale = t < a ? 0 : eOutBack(P(t, a, .3)); });
}
function badge(L, text, x, y, size, seed, bg) { return new Chip(L, text, x, y, size, seed, { rot: (hash(seed) - .5) * 6, font: '"Rubik Mono One"', bg }); }
function emoji(L, ch, x, y, size) {
  const e = el("div", "emo", L, ch); Object.assign(e.style, { position: "absolute", left: x + "px", top: y + "px", fontSize: size + "px" }); e.style.visibility = "hidden";
  return (t, a) => { e.style.visibility = t >= a ? "visible" : "hidden"; e.style.scale = t >= a ? eOutBack(P(t, a, .35)) : 0; e.style.rotate = (Math.sin(t * 3 + x) * 6) + "deg"; };
}
const pop = (c, t, a, extra = {}) => { const p = placeIn(t, a); c.set(t, { ...p, ...extra, dy: (p.dy || 0) + (extra.dy || 0) }); };
function along(pts, k) { const f = clamp(k) * (pts.length - 1), i = Math.min(pts.length - 2, Math.floor(f)), r = f - i; return [lerp(pts[i][0], pts[i + 1][0], r), lerp(pts[i][1], pts[i + 1][1], r)]; }

// ---------- scenes ----------
defScene("s1", (L, s) => {
  const studs = new Cut(L, "students", 1460, 1040, 450), mascot = new Cut(L, "mascot", 380, 1010, 260);
  const issai = badge(L, "ISSAI", 960, 160, 120, 3);
  const frp = badge(L, "FALL RESEARCH PROGRAM 2026", 960, 305, 54, 5);
  const nu = paperTag(L, '<span class="mono">NAZARBAYEV UNIVERSITY, ASTANA</span>', 110, 430, { size: 38, rot: -3 });
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.12, y0: 0, y1: -20 });
    issai.set(t, wt("s1", "ISSAI") - .15); frp.set(t, wt("s1", "research") - .1);
    showTag(nu, t, wt("s1", "Nazarbayev") - .1);
    pop(studs, t, wt("s1", "students") - .2); pop(mascot, t, wt("s1", "opens"), { r: Math.sin(t * 4) * 4 });
  } };
});

defScene("s2", (L, s) => {
  const TEALR = [[333, 568], [517, 551], [689, 574], [872, 540], [1033, 511], [1205, 505], [1378, 540], [1527, 620], [1630, 666]];
  const CORALR = [[333, 597], [482, 643], [597, 735], [746, 792], [918, 792], [1091, 758], [1263, 735], [1435, 758], [1607, 689]];
  const head = badge(L, "8 DAYS", 960, 95, 84, 9), paths = badge(L, "2 PATHS", 960, 210, 64, 10);
  const ai = badge(L, "AI ENGINEERING", 760, 420, 52, 11, TEAL), rob = badge(L, "ROBOTICS", 1250, 860, 56, 12, CORAL);
  const mascot = new Cut(L, "mascot", 0, 0, 120), drone = new Cut(L, "drone", 0, 0, 110);
  const demo = badge(L, "DEMO DAY", 1610, 470, 40, 13);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.0 });
    head.set(t, wt("s2", "Eight") - .1); paths.set(t, wt("s2", "paths") - .1);
    ai.set(t, wt("s2", "AI") - .1); rob.set(t, wt("s2", "Robotics") - .1); demo.set(t, wt("s2", "move") - .1);
    const ka = P(t, wt("s2", "AI"), 3.2), kr = P(t, wt("s2", "Robotics"), 2.6);
    [mascot.x, mascot.y] = along(TEALR, ka); mascot.y += 8; mascot.set(t, { s: t >= wt("s2", "AI") - .1 ? 1 : 0, dy: -Math.abs(Math.sin(t * 9)) * 10 });
    [drone.x, drone.y] = along(CORALR, kr); drone.y -= 40; drone.set(t, { s: t >= wt("s2", "Robotics") - .1 ? 1 : 0, r: Math.sin(t * 7) * 6, boil: .5 });
  } };
});

defScene("s3", (L, s) => {
  const ln = lanes(L, [1], "both"), studs = new Cut(L, "students", 600, 1050, 440), mascot = new Cut(L, "mascot", 1380, 1010, 250);
  const day = badge(L, "DAY 1", 960, 210, 90, 21), all = badge(L, "FOR EVERYONE", 960, 330, 56, 22);
  const e1 = emoji(L, "🍕", 1560, 640, 110), e2 = emoji(L, "🎉", 240, 560, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.08, s1: 1.0 }); ln(t);
    day.set(t, wt("s3", "Day") - .15); all.set(t, wt("s3", "everyone") - .1);
    pop(studs, t, wt("s3", "opening") - .2); e2(t, wt("s3", "ceremony")); pop(mascot, t, wt("s3", "tour") - .2, { r: Math.sin(t * 5) * 5 });
    e1(t, wt("s3", "pizza"));
  } };
});

defScene("s4", (L, s) => {
  const ln = lanes(L, [2, 3, 4, 5, 6, 7], "ai"), coder = new Cut(L, "coder", 560, 1040, 420), mascot = new Cut(L, "mascot", 1350, 1010, 280);
  const tr = badge(L, "AI TRACK", 960, 210, 84, 31, TEAL), ag = badge(L, "LEAD AI AGENTS", 960, 355, 54, 32);
  const sc = paperTag(L, '<span class="mono">ISSAI SUPERCOMPUTER</span>', 1150, 470, { size: 36, rot: 3 });
  const e1 = emoji(L, "🧠", 900, 560, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.05, s1: 1.14 }); ln(t);
    tr.set(t, wt("s4", "AI") - .15); pop(coder, t, wt("s4", "students") - .2); e1(t, wt("s4", "thinks"));
    ag.set(t, wt("s4", "lead") - .1); pop(mascot, t, wt("s4", "agents") - .2, { r: Math.sin(t * 5) * 5 });
    showTag(sc, t, wt("s4", "supercomputer") - .1);
  } };
});

defScene("s5", (L, s) => {
  const ln = lanes(L, [1, 2, 3], "rob"), maker = new Cut(L, "maker", 560, 1040, 430), printer = new Cut(L, "printer", 1380, 1020, 380);
  const tr = badge(L, "ROBOTICS TRACK", 960, 210, 76, 41, CORAL), cad = badge(L, "CAD + ARDUINO", 960, 355, 56, 42);
  const e1 = emoji(L, "⚡", 860, 560, 100), e2 = emoji(L, "⚙️", 1100, 600, 90);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.04 }); ln(t);
    tr.set(t, wt("s5", "robotics") - .15); pop(printer, t, wt("s5", "design") - .2); cad.set(t, wt("s5", "CAD") - .1);
    pop(maker, t, wt("s5", "wire") - .2); e1(t, wt("s5", "Arduino")); e2(t, wt("s5", "motors"));
  } };
});

defScene("s6", (L, s) => {
  const ln = lanes(L, [4, 5, 6, 7], "ai"), senses = new Cut(L, "senses", 1380, 1020, 400), coder = new Cut(L, "coder", 520, 1040, 380);
  const tr = badge(L, "AI PROJECTS", 960, 200, 80, 51, TEAL);
  const w = [["HEAR", 540, 400], ["SPEAK", 960, 420], ["SEE", 1360, 400]].map(([tx, x, y], i) => badge(L, tx, x, y, 60, 52 + i));
  const kz = paperTag(L, '<span class="mono">KAZAKH SPEECH</span>', 830, 520, { size: 36, rot: -2 });
  const e1 = emoji(L, "🌍", 1650, 560, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.04, x0: 20, x1: -20 }); ln(t);
    tr.set(t, wt("s6", "AI") - .15); pop(coder, t, wt("s6", "projects") - .1);
    w[0].set(t, wt("s6", "hear") - .1); w[1].set(t, wt("s6", "speak") - .1); w[2].set(t, wt("s6", "see") - .1);
    pop(senses, t, wt("s6", "voice") - .2); showTag(kz, t, wt("s6", "Kazakh") - .1); e1(t, wt("s6", "world"));
  } };
});

defScene("s7", (L, s) => {
  const ln = lanes(L, [4, 5, 6, 7], "rob"), drone = new Cut(L, "drone", 0, 0, 230);
  const tr = badge(L, "ROBOTICS PROJECTS", 960, 200, 70, 61, CORAL), f8 = badge(L, "FIGURE 8!", 960, 320, 64, 62);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.08 }); ln(t);
    tr.set(t, wt("s7", "Robotics") - .15); f8.set(t, wt("s7", "figure") - .1);
    const a = wt("s7", "off") - .2, u = Math.max(0, t - a) * 1.6;  // take off, then a figure-eight (lemniscate) in the air
    const lift = eOutCubic(P(t, a, .8));
    drone.x = 960 + 520 * Math.sin(u) * lift; drone.y = lerp(1000, 700, lift) + 170 * Math.sin(u) * Math.cos(u) * lift;
    drone.set(t, { s: t >= a - .2 ? 1 : 0, r: Math.cos(u) * 12 * lift, boil: .4 });
  } };
});

defScene("s8", (L, s) => {
  const ln = lanes(L, [4, 5, 6, 7], "rob"), soft = new Cut(L, "softrobot", 560, 1030, 520), arm = new Cut(L, "arm", 1400, 1030, 460);
  const b1 = badge(L, "SOFT ROBOT", 560, 330, 58, 71, CORAL), b2 = badge(L, "ROBOTIC ARM", 1400, 330, 58, 72, CORAL);
  const e1 = emoji(L, "🐘", 860, 520, 100), e2 = emoji(L, "📦", 1120, 620, 90);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.06, s1: 1.12 }); ln(t);
    pop(soft, t, wt("s8", "soft") - .2, { r: Math.sin(t * 2.2) * 9 }); b1.set(t, wt("s8", "soft") - .1); e1(t, wt("s8", "elephant"));
    pop(arm, t, wt("s8", "robotic") - .2, { r: Math.sin(t * 3) * 5 }); b2.set(t, wt("s8", "robotic") - .1); e2(t, wt("s8", "pick"));
  } };
});

defScene("s9", (L, s) => {
  const ln = lanes(L, [5, 6, 7], "both"), maker = new Cut(L, "maker", 470, 1040, 400), mascot = new Cut(L, "mascot", 1450, 1010, 270);
  const both = badge(L, "BOTH TRACKS", 960, 210, 80, 81);
  const w = [["TEST", 480, 420], ["MEASURE", 960, 520], ["IMPROVE", 1440, 420]].map(([tx, x, y], i) => badge(L, tx, x, y, 58, 82 + i));
  const e1 = emoji(L, "📈", 1660, 560, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.04, s1: 1.12 }); ln(t);
    both.set(t, wt("s9", "both") - .15); pop(maker, t, wt("s9", "students") - .2); pop(mascot, t, wt("s9", "students"), { r: Math.sin(t * 5) * 5 });
    w[0].set(t, wt("s9", "test") - .1); w[1].set(t, wt("s9", "measure") - .1); w[2].set(t, wt("s9", "improve") - .1); e1(t, wt("s9", "engineers"));
  } };
});

defScene("s10", (L, s) => {
  const ln = lanes(L, [8], "both"), pres = new Cut(L, "presenter", 1300, 1030, 520), drone = new Cut(L, "drone", 0, 0, 150), arm = new Cut(L, "arm", 420, 1040, 330);
  const day = badge(L, "DAY 8", 960, 210, 90, 91), demo = badge(L, "DEMO DAY!", 960, 330, 70, 92);
  const conf = hearts(L, 70), e1 = emoji(L, "👏", 820, 600, 100);
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.0, s1: 1.1 }); ln(t);
    day.set(t, wt("s10", "Day") - .15); demo.set(t, wt("s10", "Demo") - .1);
    const u = t * 1.4; drone.x = 960 + 600 * Math.sin(u); drone.y = 560 + 90 * Math.sin(2 * u);
    drone.set(t, { s: t >= wt("s10", "Drones") - .2 ? 1 : 0, r: Math.cos(u) * 10, boil: .4 });
    pop(arm, t, wt("s10", "robots") - .2, { r: Math.sin(t * 3) * 6 });
    pop(pres, t, wt("s10", "talk") - .3, { r: Math.sin(t * 3) * 2 }); e1(t, wt("s10", "friends"));
    conf(t, clamp((t - wt("s10", "Demo")) / .6));
  } };
});

defScene("s11", (L, s) => {
  const studs = new Cut(L, "students", 480, 1040, 430), mascot = new Cut(L, "mascot", 1080, 1020, 250), drone = new Cut(L, "drone", 0, 0, 140);
  const two = badge(L, "TWO TRACKS, ONE GOAL", 960, 180, 64, 101), real = badge(L, "BUILD SOMETHING REAL", 960, 310, 56, 102);
  const card = el("div", "endcard", L, '<div class="t1">ISSAI FRP 2026</div><div class="t2">AI ENGINEERING + ROBOTICS</div><div class="t3">24-31 October, Nazarbayev University, Astana</div>');
  card.style.visibility = "hidden";
  return { update(t) {
    kenBurns(this.bg, t, s.dur, { s0: 1.12, s1: 1.0, y0: -20, y1: 0 });
    const c = wt("s11", "Join") - .1;
    two.set(t, wt("s11", "Two") - .1, { out: c }); real.set(t, wt("s11", "build") - .1, { out: c });
    pop(studs, t, wt("s11", "tracks") - .1); pop(mascot, t, wt("s11", "goal") - .2, { r: Math.sin(t * 5) * 5, dy: -Math.abs(Math.sin(t * 8)) * 10 });
    const u = t * 1.2; drone.x = 1500 + 220 * Math.sin(u); drone.y = 640 + 60 * Math.sin(2 * u); drone.set(t, { s: t >= wt("s11", "real") ? 1 : 0, r: Math.cos(u) * 8, boil: .4 });
    card.style.visibility = t >= c ? "visible" : "hidden";
    card.style.transform = `translate(-50%, 0) rotate(${-2 + boil(9, t).r}deg) scale(${eOutBack(P(t, c, .45))})`;
  } };
});


