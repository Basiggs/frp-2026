"""Build web/indexv.html (1080x1920 Instagram Reels) from web/index.html: new stage size, CSS and scene layout.
Also converts assets/img/bgv_*.png -> web/a/bgv_*.webp (1080x1920)."""
import glob, pathlib
from PIL import Image

for p in glob.glob("assets/img/bgv_*.png"):
    q = pathlib.Path("web/a") / (pathlib.Path(p).stem + ".webp")
    if not q.exists(): Image.open(p).convert("RGB").resize((1080, 1920), Image.LANCZOS).save(q, quality=90)

s = open("web/index.html").read()
def sub(old, new, n=1):
    global s
    assert s.count(old) == n, (old, s.count(old)); s = s.replace(old, new)

# stage, sheets, captions
sub("#stage { position: relative; width: 1920px; height: 1080px;", "#stage { position: relative; width: 1080px; height: 1920px;")
sub(".sheet { position: absolute; left: -40px; top: 0; width: 2000px; height: 1080px;", ".sheet { position: absolute; left: -40px; top: 0; width: 1160px; height: 1920px;")
sub(".bg { position: absolute; left: 40px; top: 0; width: 1920px; height: 1080px;", ".bg { position: absolute; left: 40px; top: 0; width: 1080px; height: 1920px;")
sub(".caption { position: absolute; left: 50%; bottom: 46px; transform-origin: 50% 50%; max-width: 1500px;\n  font: 58px/1.15",
    ".caption { position: absolute; left: 50%; bottom: 300px; transform-origin: 50% 50%; max-width: 920px; width: max-content; text-align: center;\n  font: 54px/1.15")
# lanes strip: 936 px wide, below the Instagram header
sub(".lanes { position: absolute; left: 300px; top: 22px; width: 1320px; height: 116px; }", ".lanes { position: absolute; left: 72px; top: 236px; width: 936px; height: 116px; }")
sub(".lane { position: absolute; left: 0; width: 1320px; height: 52px; }", ".lane { position: absolute; left: 0; width: 936px; height: 52px; }")
sub(".lane .lbl { position: absolute; left: 0; top: 4px; width: 200px; text-align: center; font: 24px", ".lane .lbl { position: absolute; left: 0; top: 4px; width: 170px; text-align: center; font: 20px")
sub('d.style.left = (230 + i * 112) + "px";', 'd.style.left = (190 + i * 100) + "px";')
# end card
sub(".endcard { position: absolute; left: 960px; top: 290px;", ".endcard { position: absolute; left: 540px; top: 560px;")
sub(".endcard .t1 { font: 74px/1.05", ".endcard .t1 { font: 64px/1.05")
sub(".endcard .t2 { font: 40px/1.2", ".endcard .t2 { font: 34px/1.2")
# engine constants
sub("const W = 1920, H = 1080, TR = 0.6;", "const W = 1080, H = 1920, TR = 0.6;")
sub("sh.style.transform = `translateX(${(1 - p) * 2100}px)", "sh.style.transform = `translateX(${(1 - p) * 1250}px)")
sub("bg.src = `a/bg_${BG[s.id]}.webp`", "bg.src = `a/bgv_${BG[s.id]}.webp`")
sub("x = 80 + hash(i * 3.3) * 1760 +", "x = 80 + hash(i * 3.3) * (W - 160) +")
# decode retry (two scenes share one background)
sub('...[...document.images].map(i => i.decode().catch(e => { throw new Error("img " + i.src); }))',
    '...[...document.images].map(i => i.decode().catch(() => new Promise(r => setTimeout(r, 500)).then(() => i.decode())).catch(e => { throw new Error("img " + i.src + " " + e.message); }))')

a = s.index('defScene("s1"'); b = s.index("// ---------- captions ----------")
s = s[:a] + open("scenes_vertical.js").read() + "\n\n" + s[b:]
open("web/indexv.html", "w").write(s)
print("ok web/indexv.html")
