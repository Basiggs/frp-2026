"""All fal audio in parallel: one TTS clip per scene (with word timestamps), the SFX in SFX, and music if MUSIC is set.
  python gen_audio.py            everything
  python gen_audio.py s3 s4      only these scenes' voice (retakes)
Reuse a finished music track (cp ~/<old-project>/assets/audio/music.mp3 assets/audio/) to save $0.60/min."""
import json, sys, concurrent.futures as cf
from fal import run, download
from say import spoken   # ISSAI -> "Issai", Astana -> "Astaná" for the voice only (see say.py)
S = json.load(open("script.json")); only = sys.argv[1:]
MUSIC = None   # e.g. ("whimsical cozy lo-fi, pizzicato strings and celesta, 92 bpm, no vocals, ends with a soft button", 30000)
SFX = {"ding": ("short bright smartphone chat message notification ding", 1),
       "quack": ("several cute ducks quacking excitedly together, short burst", 2),
       "flap": ("a bird flapping its wings and taking off, soft feathery whoosh", 1.5),
       "coo": ("single gentle dove cooing", 1.5),
       "pop": ("soft paper pop, cardboard cutout placed on a table", 0.5),
       "chime": ("short happy magical chime sparkle", 1.5)}
def tts(sc):
    out = run("fal-ai/elevenlabs/tts/eleven-v3", {"text": spoken(sc["text"]), "voice": sc.get("voice", S["voice"]), "stability": 0.5,
                                                   "timestamps": True, "language_code": sc.get("lang", "en")})
    download(out["audio"]["url"], f"assets/audio/vo_{sc['id']}.mp3")
    json.dump(out.get("timestamps"), open(f"assets/audio/vo_{sc['id']}.json", "w")); return "vo_" + sc["id"]
def sfx(k):
    t, d = SFX[k]; out = run("fal-ai/elevenlabs/sound-effects/v2", {"text": t, "duration_seconds": d})
    download(out["audio"]["url"], f"assets/audio/sfx_{k}.mp3"); return "sfx_" + k
def music():
    out = run("fal-ai/elevenlabs/music", {"prompt": MUSIC[0], "music_length_ms": MUSIC[1], "force_instrumental": True})
    download(out["audio"]["url"], "assets/audio/music.mp3"); return "music"
with cf.ThreadPoolExecutor(10) as ex:
    jobs = [ex.submit(tts, s) for s in S["scenes"] if not only or s["id"] in only]
    if not only: jobs += [ex.submit(sfx, k) for k in SFX] + ([ex.submit(music)] if MUSIC else [])
    for f in cf.as_completed(jobs): print("done", f.result(), flush=True)
