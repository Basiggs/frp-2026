"""Minimal fal.ai queue client: run(model, args) -> result dict. Logs every call.

Key: $FAL_KEY, else ~/.config/fal/key.
CLI:  python fal.py <model> '<json args>'     run one call
      python fal.py cost                      estimate spend from fal_log.jsonl
"""
import json, os, sys, time, pathlib, requests

ROOT = pathlib.Path(__file__).parent
KEY = os.environ.get("FAL_KEY") or (pathlib.Path.home() / ".config/fal/key").read_text().strip()
H = {"Authorization": f"Key {KEY}", "Content-Type": "application/json"}


def run(model, args, timeout=600):
    t0 = time.time()
    r = requests.post(f"https://queue.fal.run/{model}", headers=H, json=args, timeout=60)
    r.raise_for_status()
    sub = r.json()
    while True:
        s = requests.get(sub["status_url"], headers=H, timeout=60).json()
        if s["status"] == "COMPLETED":
            break
        if time.time() - t0 > timeout:
            raise TimeoutError(f"{model} timed out: {s}")
        time.sleep(2)
    res = requests.get(sub["response_url"], headers=H, timeout=60)
    res.raise_for_status()
    out = res.json()
    with open(ROOT / "fal_log.jsonl", "a") as f:
        f.write(json.dumps({"model": model, "secs": round(time.time() - t0, 1),
                            "args": {k: v for k, v in args.items() if k != "text"},
                            "chars": len(args.get("text", ""))}) + "\n")
    return out


def download(url, path):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    r = requests.get(url, timeout=120)
    r.raise_for_status()
    path.write_bytes(r.content)
    return path


def units(unit, e):
    """Billable units of one logged call, for the price units fal reports."""
    a = e["args"]
    if unit.startswith("image"):
        return a.get("num_images", 1)
    if unit == "1000 characters":
        return e["chars"] / 1000
    if unit == "minutes":
        return a["music_length_ms"] / 60000
    if unit == "seconds":
        return a["duration_seconds"]
    if unit == "megapixels" and a.get("upscale_mode") == "target":  # SeedVR upscale; 16:9 output assumed
        h = int(a["target_resolution"][:-1])
        return h * h * 16 / 9 / 1e6
    if unit == "compute seconds":
        return e["secs"]  # queue wall time, an upper bound
    raise ValueError(f"unknown price unit {unit!r} for {e['model']}")


def cost():
    """Estimated spend from fal_log.jsonl × current list prices."""
    log = [json.loads(l) for l in open(ROOT / "fal_log.jsonl")]
    total = 0.0
    for model in sorted({e["model"] for e in log}):
        r = requests.get("https://api.fal.ai/v1/models/pricing", headers=H,
                         params={"endpoint_id": model}, timeout=60)
        r.raise_for_status()
        p = r.json()["prices"][0]
        es = [e for e in log if e["model"] == model]
        usd = sum(units(p["unit"], e) for e in es) * p["unit_price"]
        total += usd
        print(f"{len(es):4d} × {model:42s} ${usd:6.2f}  ({p['unit_price']} / {p['unit']})")
    print(f"{'':49s} ${total:6.2f}  total")


if __name__ == "__main__":
    if sys.argv[1] == "cost":
        cost()
    else:
        print(json.dumps(run(sys.argv[1], json.loads(sys.argv[2])), indent=1))
