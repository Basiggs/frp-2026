"""Upscale assets/img/bg_*.png to 2160p with SeedVR -> assets/img4k/ (about $0.008 each)."""
import base64, glob, pathlib, sys
from concurrent.futures import ThreadPoolExecutor
from fal import run, download

out = pathlib.Path("assets/img4k"); out.mkdir(parents=True, exist_ok=True)
pat = sys.argv[1] if len(sys.argv) > 1 else "assets/img/bg_*.png"

def up(p):
    q = out / pathlib.Path(p).name
    if q.exists(): return f"skip {q}"
    uri = "data:image/png;base64," + base64.b64encode(open(p, "rb").read()).decode()
    r = run("fal-ai/seedvr/upscale/image", {"image_url": uri, "upscale_mode": "target", "target_resolution": "2160p", "output_format": "png"})
    download(r["image"]["url"], q)
    return f"ok {q}"

with ThreadPoolExecutor(4) as ex:
    for m in ex.map(up, sorted(glob.glob(pat))): print(m)
