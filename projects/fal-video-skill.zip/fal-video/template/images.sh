#!/usr/bin/env bash
# Images with Codex (free; 2-4 min each, run in parallel). Characters/props on plain white -> cutout.py; backgrounds as bg_*.png.
# One shared style prefix keeps everything consistent. Edit the requests, then: bash images.sh && wait
C=~/skills/codex-image-gen/scripts/codex_img.sh
S="Hand-made paper collage illustration: cut paper, torn edges, gouache and colored-pencil texture, visible paper grain, cute and funny, no text, no letters"
W="$S, single subject centered on a plain pure white background"
$C assets/img/ducks.png "$W. Subject: a team of five cute yellow paper ducklings in a row, cheering, full bodies visible." &
$C assets/img/dove.png "$W. Subject: a cute white paper dove flying right, wings open, a small envelope in its beak." &
$C assets/img/bg_pond.png "$S, 16:9 landscape background, empty foreground for characters. Scene: an autumn park pond with a small wooden bridge." &
wait
