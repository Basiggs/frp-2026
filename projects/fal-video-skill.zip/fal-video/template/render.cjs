// usage: node render.cjs frames [fps] [workers]   |   node render.cjs stills t1 t2 ...
// RESUME=1 node render.cjs frames 30 2   keeps frames already in render/frames (after a stopped render)
// VW=1080 VH=1920 sets the page size (default 1920x1080). DPR=2 renders at 2x pixels (1920x1080 page -> 4K frames).
// OUT=render/frames4k writes frames to another folder.
const { chromium } = require(process.env.HOME + "/.claude/skills/gstack/node_modules/playwright");
const fs = require("fs"), path = require("path");
const URL = "file://" + path.resolve(process.env.PAGE || "web/index.html");
const VW = +(process.env.VW || 1920), VH = +(process.env.VH || 1080), DPR = +(process.env.DPR || 1);
const OUT = process.env.OUT || "render/frames";
async function page(browser) {
  const p = await browser.newPage({ viewport: { width: VW, height: VH }, deviceScaleFactor: DPR });
  const errs = []; p.on("pageerror", e => errs.push(e.message)); p.on("console", m => m.type() === "error" && errs.push(m.text()));
  await p.goto(URL); await p.evaluate(() => { document.body.classList.add("render"); return window.READY; });
  if (errs.length) throw new Error(errs.join("\n"));
  return p;
}
(async () => {
  const [mode, ...rest] = process.argv.slice(2);
  const browser = await chromium.launch({ args: ["--allow-file-access-from-files", "--disable-web-security"] });
  if (mode === "stills") {
    const p = await page(browser); fs.mkdirSync("render/stills", { recursive: true });
    for (const t of rest) { await p.evaluate(t => window.seek(+t), t); await p.screenshot({ path: `render/stills/t${(+t).toFixed(2)}.jpg`, type: "jpeg", quality: 80 }); }
  } else {
    const fps = +(rest[0] || 30), nw = +(rest[1] || 3);
    const p0 = await page(browser); const total = await p0.evaluate(() => window.TOTAL); await p0.close();
    const N = Math.ceil(total * fps); fs.mkdirSync(OUT, { recursive: true });
    let next = 0, done = 0; const t0 = Date.now();
    await Promise.all([...Array(nw)].map(async () => {
      const p = await page(browser);
      while (next < N) {
        const f = next++;
        const out = `${OUT}/f${String(f).padStart(5, "0")}.jpg`;
        if (process.env.RESUME && fs.existsSync(out) && fs.statSync(out).size > 0) { ++done; continue; }
        await p.evaluate(t => window.seek(t), f / fps);
        await p.screenshot({ path: out, type: "jpeg", quality: 92 });
        if (++done % 150 === 0) console.log(`${done}/${N} ${((Date.now() - t0) / 1000).toFixed(0)}s`);
      }
    }));
    console.log("frames", N);
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
