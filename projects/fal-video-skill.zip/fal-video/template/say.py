"""Pronunciation fixes for the TTS voice, chosen by Kitan by ear (2026-10-09).
Write the official spelling in script.json. gen_audio.py sends spoken(text) to the TTS;
prep.py puts the official spelling back into the caption words with shown(word).
To add a word: make 5-7 test clips with different spellings, let Kitan pick one, add it here."""
import re

SAY = {
    "ISSAI": "Issai",    # one word, not the letters I-S-S-A-I (Kitan picked test version 2 of 6)
    "Astana": "Astaná",  # stress on the last syllable: Asta-NA (Kitan picked test version 2 of 7)
}

def spoken(text):
    for official, said in SAY.items():
        text = re.sub(rf"\b{re.escape(official)}\b", said, text)
    return text

def shown(word):
    for official, said in SAY.items():
        word = word.replace(said, official)
    return word
