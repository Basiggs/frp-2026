"""Local cut-out for Codex props on plain white (16 Oct 2026: fal balance was empty, so no BiRefNet).
Removes near-white pixels connected to the border, plus big enclosed pure-white holes; soft 1.5 px edge.
usage: python3 cutout_local.py scissors river bankhouse   -> web/a/o_<name>.webp"""
import sys
import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

for name in sys.argv[1:]:
    im = Image.open(f"assets/img/{name}.png").convert("RGB")
    a = np.asarray(im).astype(int)
    white = (a.min(axis=2) > 236) & (a.max(axis=2) - a.min(axis=2) < 18)
    lab, n = ndimage.label(white)
    edge = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    sizes = ndimage.sum(np.ones_like(lab), lab, range(1, n + 1))
    holes = {i + 1 for i, s in enumerate(sizes) if s > 2500 and (a[lab == i + 1].mean() > 243)}
    bg = np.isin(lab, list(edge | holes))
    alpha = Image.fromarray(np.where(bg, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.5))
    out = im.convert("RGBA"); out.putalpha(alpha)
    out = out.crop(alpha.point(lambda v: 255 if v > 20 else 0).getbbox())
    if out.height > 1000:
        out = out.resize((round(out.width * 1000 / out.height), 1000), Image.LANCZOS)
    out.save(f"web/a/o_{name}.webp", quality=92)
    print(name, out.size, "holes removed:", len(holes))
