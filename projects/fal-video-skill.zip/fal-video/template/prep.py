"""Voice clips -> web/timeline.js (word times) and web/mix.m4a (voice 1x + ducked music + SFX on words).
Also converts assets/img/bg_*.png -> web/a/bg_*.webp (1920x1080). Settings live in cfg.json:
  music        path of the music file (optional)
  music_tempo  atempo for the music only (voice is never sped up)
  lead / tail  seconds of silence before / after each scene's voice
  cues         [scene, word prefix or null (= scene start), sfx name, offset s, gain] -> assets/audio/sfx_<name>.mp3
"""
import glob, json, pathlib, subprocess
from PIL import Image
from say import shown   # captions show the official spelling (ISSAI, Astana) of what the voice says differently
CFG = json.load(open("cfg.json")); S = json.load(open("script.json"))
LEAD, TAIL = CFG.get("lead", {}), CFG.get("tail", {})
out = pathlib.Path("web/a"); out.mkdir(parents=True, exist_ok=True)
for p in glob.glob("assets/img/bg_*.png"):
    q = out / (pathlib.Path(p).stem + ".webp")
    if not q.exists(): Image.open(p).convert("RGB").resize((1920, 1080)).save(q, quality=88)
def dur(f): return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f]))
t, scenes, clips = 0.0, [], []
for sc in S["scenes"]:
    sid = sc["id"]; vo = f"assets/audio/vo_{sid}.mp3"; lead = LEAD.get(sid, 0.4); words, w = [], None
    for ch in json.load(open(f"assets/audio/vo_{sid}.json")):
        for c, s, e in zip(ch["characters"], ch["character_start_times_seconds"], ch["character_end_times_seconds"]):
            if c.isspace():
                if w: words.append(w); w = None
            else:
                if not w: w = {"w": "", "s": round(lead + s, 3)}
                w["w"] += c; w["e"] = round(lead + e, 3)
    if w: words.append(w)
    words = [x for x in words if not x["w"].startswith("[")]          # drop v3 audio tags like [laughs]
    for x in words: x["w"] = shown(x["w"])
    d = lead + dur(vo) + TAIL.get(sid, 0.5)
    clips.append((vo, t + lead)); scenes.append({"id": sid, "start": round(t, 3), "dur": round(d, 3), "words": words}); t += d
total = round(t, 3)
open("web/timeline.js", "w").write("window.TL=" + json.dumps({"total": total, "scenes": scenes}) + ";")
def wt(sid, key):
    sc = next(s for s in scenes if s["id"] == sid)
    if key is None: return sc["start"]
    return sc["start"] + next(w for w in sc["words"] if w["w"].strip('.,?!:"').lower().startswith(key.lower()))["s"]
inputs, filt, labels, n = [], [], [], 0
for f, at in clips:
    ms = int(at * 1000); inputs += ["-i", f]; filt.append(f"[{n}:a]aformat=channel_layouts=stereo,aresample=44100,adelay={ms}|{ms}[v{n}]"); labels.append(f"[v{n}]"); n += 1
filt.append("".join(labels) + f"amix=inputs={len(labels)}:normalize=0,asplit=2[vo][sc]")
sx = []
for sid, key, k, off, g in CFG.get("cues", []):
    ms = max(0, int((wt(sid, key) + off) * 1000)); inputs += ["-i", f"assets/audio/sfx_{k}.mp3"]
    filt.append(f"[{n}:a]aformat=channel_layouts=stereo,aresample=44100,volume={g},adelay={ms}|{ms}[x{n}]"); sx.append(f"[x{n}]"); n += 1
mix = ["[vo]"] + sx
if CFG.get("music"):
    inputs += ["-i", CFG["music"]]; mt = CFG.get("music_tempo", 1.0)
    filt.append(f"[{n}:a]aformat=channel_layouts=stereo,aresample=44100,atempo={mt},atrim=0:{total},volume=0.6,afade=t=in:d=0.8,"
                f"afade=t=out:st={max(0, total - 1.6)}:d=1.6,apad,atrim=0:{total}[m]")
    filt.append("[m][sc]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=400[md]"); mix.append("[md]")
else:
    filt.append("[sc]anullsink")
filt.append("".join(mix) + f"amix=inputs={len(mix)}:normalize=0,loudnorm=I=-16:TP=-1.5,apad,atrim=0:{total}[out]")
subprocess.run(["ffmpeg", "-y", "-v", "error", *inputs, "-filter_complex", ";".join(filt), "-map", "[out]", "-ar", "48000", "-c:a", "aac", "-b:a", "192k", "web/mix.m4a"], check=True)
print("total", total)
for s in scenes: print(s["id"], s["start"], " ".join(f'{w["w"]}@{w["s"]:.1f}' for w in s["words"]))
