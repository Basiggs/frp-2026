"""FALLBACK only (Codex is the default and free): one Nano Banana 2 image at 1K.
  python fal_image.py assets/img/bg_park.png "prompt" [16:9|1:1] [ref_url ...]
With ref URLs it uses /edit, which keeps a character on-model. Prints the fal URL so it can be a later ref."""
import sys
from fal import run, download
out_path, prompt = sys.argv[1], sys.argv[2]; ar = sys.argv[3] if len(sys.argv) > 3 else "16:9"; refs = sys.argv[4:]
args = {"prompt": prompt, "resolution": "1K", "aspect_ratio": ar, "output_format": "png"}
if refs: args["image_urls"] = refs
url = run("fal-ai/nano-banana-2/edit" if refs else "fal-ai/nano-banana-2", args)["images"][0]["url"]
download(url, out_path); print(out_path, url)
