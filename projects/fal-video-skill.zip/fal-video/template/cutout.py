"""Cut-outs: assets/img/<name>.png (subject on plain white) -> BiRefNet on fal -> web/a/o_<name>.webp with a paper outline.
  python cutout.py ducks,dove"""
import base64, io, sys
from PIL import Image, ImageFilter
from fal import run, download
def cut(n):
    b = io.BytesIO(); im = Image.open(f"assets/img/{n}.png").convert("RGB"); im.thumbnail((1024, 1024)); im.save(b, "PNG")
    out = run("fal-ai/birefnet/v2", {"image_url": "data:image/png;base64," + base64.b64encode(b.getvalue()).decode(), "model": "General Use (Heavy)", "output_format": "png"})
    download(out["image"]["url"], f"assets/img/{n}_cut.png")
    im = Image.open(f"assets/img/{n}_cut.png").convert("RGBA"); im = im.crop(im.getbbox()); pad = 16
    big = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad), (0, 0, 0, 0)); big.paste(im, (pad, pad))
    a = big.getchannel("A").point(lambda v: 255 if v > 90 else 0).filter(ImageFilter.MaxFilter(13)).filter(ImageFilter.GaussianBlur(1.2))
    w = Image.new("RGBA", big.size, (250, 247, 238, 255)); w.putalpha(a)
    Image.alpha_composite(w, big).save(f"web/a/o_{n}.webp", quality=90); print("cut", n)
for n in sys.argv[1].split(","): cut(n)
