#!/usr/bin/env bash
# Scaffold a new fal.ai paper-collage video project from the template.
#   bash ~/skills/fal-video/new.sh ~/my-video
set -euo pipefail
dest="${1:?usage: new.sh <project-dir>}"
[[ -e "$dest" ]] && { echo "exists: $dest" >&2; exit 1; }
[[ -s ~/.config/fal/key || -n "${FAL_KEY:-}" ]] || { echo "no fal key: set FAL_KEY or write ~/.config/fal/key" >&2; exit 1; }
cp -r "$(dirname "$(readlink -f "$0")")/template" "$dest"
mkdir -p "$dest"/assets/{img,audio} "$dest"/web/a
echo "scaffolded $dest"
